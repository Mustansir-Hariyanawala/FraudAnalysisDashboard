package com.example.demo.repository;

import com.example.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByCustomerId(String customerId);
    boolean existsByCustomerId(String customerId);
    boolean existsByEmailId(String emailId);
}